<script>

document.querySelectorAll('.editor').forEach((element) => {

    ClassicEditor
        .create(element)
        .catch(error => {
            console.error(error);
        });

});

</script>
